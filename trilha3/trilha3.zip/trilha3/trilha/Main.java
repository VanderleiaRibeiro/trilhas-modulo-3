public class Main {
    public static void main(String[] args) {
        Aluno aluno1 = new Aluno("Lucas", 10, 40, 1.60);
        Aluno aluno2 = new Aluno("Laura", 1, 10, 52);

        aluno1.exibirInformacoes();
//        System.out.println();
        aluno2.exibirInformacoes();
    }
}
