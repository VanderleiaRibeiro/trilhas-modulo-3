public class Universidade {
    private String nome;

    public Universidade(String nome) {
        this.nome = nome;
    }

    public String getNome() {
        return nome;
    }
}
